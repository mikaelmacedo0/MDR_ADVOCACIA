# Matriz de permissões — JurisAcompanha

Legenda:
- **Sim**: permitido conforme escopo e vínculo.
- **Condicional**: somente com autorização específica e validação no servidor/banco.
- **Não**: negado por padrão.

Esta matriz é um ponto de partida. A política efetiva será definida em RLS, privilégios SQL, Storage e funções de servidor.

| Recurso/ação | Superadmin plataforma | Admin escritório | Advogado | Colaborador | Cliente |
|---|---|---|---|---|---|
| Ver configurações globais do SaaS | Sim | Não | Não | Não | Não |
| Ler conteúdo jurídico de um tenant | Não por padrão; exceção formal e auditada | Condicional ao próprio tenant | Condicional ao processo atribuído | Condicional à permissão | Não, salvo conteúdo liberado e vínculo |
| Gerenciar usuários do próprio escritório | Não por padrão | Sim | Não por padrão | Não | Não |
| Gerenciar memberships e papéis | Operações globais limitadas | Condicional ao próprio tenant, sem autoelevação | Não por padrão | Não | Não |
| Criar/editar cadastro de cliente | Não por padrão | Sim | Condicional | Condicional | Não |
| Criar/editar processo | Não por padrão | Sim | Condicional à atribuição/permissão | Condicional | Não |
| Consultar processo | Não por padrão | Sim no tenant | Condicional à atribuição | Condicional à atribuição | Somente se vinculado |
| Publicar movimentação | Não por padrão | Condicional | Sim se autorizado | Condicional | Não |
| Publicar atualização para cliente | Não por padrão | Condicional | Sim se autorizado | Condicional | Não |
| Ler atualização publicada | Não por padrão | Sim no tenant | Sim se autorizado | Condicional | Sim, se vinculada ao cliente/processo |
| Ler anotação interna | Não por padrão | Sim no tenant, conforme necessidade | Condicional | Condicional | Não |
| Enviar documento | Não por padrão | Sim no tenant | Condicional | Condicional | Não, salvo futura função específica |
| Baixar documento interno | Não por padrão | Condicional | Condicional | Condicional | Não |
| Baixar documento liberado | Não por padrão | Sim no tenant | Condicional | Condicional | Sim, se vinculado e autorizado |
| Gerenciar agenda do escritório | Não por padrão | Sim | Condicional | Condicional | Não |
| Ver evento compartilhado | Não por padrão | Sim no tenant | Condicional | Condicional | Somente eventos explicitamente liberados |
| Gerenciar notificações | Configuração global limitada | Sim no tenant | Condicional | Condicional | Preferências próprias permitidas |
| Ver logs de auditoria | Logs operacionais globais minimizados | Condicional ao tenant | Restrito conforme política | Não por padrão | Não |
| Solicitar acesso/correção de dados próprios | Conforme processo aplicável | Conforme processo aplicável | Conforme processo aplicável | Conforme processo aplicável | Sim, por fluxo seguro |

## Regras inegociáveis

1. A autorização é verificada no servidor/banco, não somente na interface.
2. O tenant vem de membership confiável, não de um valor livre enviado pelo cliente.
3. Acesso a processo exige vínculo ou permissão explícita.
4. Acesso a documento exige autorização tanto para metadados quanto para download.
5. O estado `client_visible` não é suficiente sozinho: também é necessário vínculo válido do cliente com o processo e tenant.
6. Operações de superadmin não dão acesso irrestrito ao conteúdo jurídico.
7. Usuários não podem editar o próprio papel ou ampliar seus próprios vínculos.
8. Funções privilegiadas devem validar o ator e o recurso e registrar operações sensíveis.
9. Busca, paginação, exportação, notificações e downloads devem obedecer às mesmas regras.
10. A ausência de política permissiva deve resultar em negação de acesso.

## Testes de autorização mínimos

- Cliente A tenta ler processo de Cliente B.
- Cliente A troca UUID do documento e tenta baixar arquivo de Cliente B.
- Advogado do Escritório A tenta acessar processo do Escritório B.
- Colaborador tenta publicar atualização sem permissão.
- Cliente tenta inserir ou alterar movimentação diretamente via API.
- Usuário tenta alterar `tenant_id`, papel ou membership.
- Documento interno é solicitado por uma sessão de cliente.
- Usuário desativado tenta reutilizar sessão ou link de convite expirado.
