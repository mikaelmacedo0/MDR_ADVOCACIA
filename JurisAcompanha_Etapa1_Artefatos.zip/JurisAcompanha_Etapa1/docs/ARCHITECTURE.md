# Arquitetura — JurisAcompanha

## 1. Objetivo

Construir um SaaS jurídico multi-tenant para escritórios de advocacia e seus clientes, priorizando confidencialidade, integridade, rastreabilidade e minimização de dados.

## 2. Stack inicial

- Front-end: React + TypeScript + Vite.
- UI: Tailwind CSS e componentes acessíveis.
- Identidade: Supabase Auth.
- Banco: PostgreSQL gerenciado pelo Supabase.
- Autorização: RLS no PostgreSQL, privilégios SQL mínimos e validação em serviços de servidor.
- Documentos: Supabase Storage com buckets privados e políticas específicas.
- Operações privilegiadas/integradores: Supabase Edge Functions quando necessário.
- Testes: Vitest para unidades/integração; Playwright para fluxos ponta a ponta; testes SQL/RLS com usuários distintos.
- Versionamento: Git; migrações versionadas no repositório.

## 3. Diagrama lógico

```mermaid
flowchart TD
    U[Advogado / Colaborador / Cliente] --> WEB[React + TypeScript]
    WEB --> AUTH[Supabase Auth]
    WEB --> DB[(PostgreSQL + RLS)]
    WEB --> ST[Storage privado]
    WEB --> EF[Edge Functions]
    EF --> DB
    EF --> ST
    DB --> AUD[Auditoria e eventos de segurança]
    DB --> NOTIF[Registros de notificação]
    NOTIF --> MAIL[Provedor de e-mail configurado]
```

## 4. Limites de confiança

1. Navegador: ambiente não confiável. Não armazenar segredos privilegiados.
2. Auth: comprova a identidade, mas não substitui a autorização por recurso.
3. PostgreSQL: fonte principal das regras de acesso a dados; RLS e privilégios devem ser testados.
4. Storage: arquivos privados, acesso restrito por políticas; autorização verificada antes de emitir URL assinada.
5. Edge Functions: validar identidade, tenant, papel e vínculo com o recurso; validar todos os parâmetros.
6. E-mail: canal externo. Mensagens devem minimizar informações jurídicas e nunca anexar documentos confidenciais por padrão.
7. Logs: restritos e minimizados; nunca incluir senhas, tokens, cookies ou conteúdo integral de documentos.

## 5. Princípios obrigatórios

- Deny by default: negar acesso por padrão.
- Least privilege: menor privilégio necessário.
- Separação entre tenants em tabelas, consultas, arquivos, funções e notificações.
- RLS nas tabelas expostas que contenham dados privados.
- Políticas específicas por operação (SELECT, INSERT, UPDATE, DELETE).
- IDs imprevisíveis não substituem autorização.
- Alterações de papéis e memberships apenas por fluxos confiáveis.
- Migrações versionadas, reproduzíveis e revisadas.
- Ambientes separados: desenvolvimento, homologação e produção.
- Dados fictícios em desenvolvimento e testes.
- Backups e restauração testados antes de produção.

## 6. Fluxos principais

### Login
1. Usuário autentica via Supabase Auth.
2. Aplicação obtém a sessão do usuário.
3. Banco/serviço valida tenant, membership, papel e estado da conta em cada operação.
4. A interface apresenta somente os recursos autorizados; isso é usabilidade, não a barreira de segurança principal.

### Download de documento
1. Usuário solicita o documento.
2. Serviço valida sessão, tenant, vínculo com o processo e visibilidade.
3. Só então emite URL assinada de curta duração ou faz o download autorizado.
4. A ação relevante é registrada sem guardar o conteúdo do arquivo no log.

### Publicação para cliente
1. Advogado autorizado cria ou edita atualização.
2. Sistema registra autoria e timestamps.
3. A publicação para cliente é uma ação explícita e auditada.
4. Atualizações internas não são retornadas ao cliente.

## 7. Decisões ainda pendentes

- Se um cliente pode estar vinculado a mais de um escritório e em quais condições.
- Se o superadministrador terá apenas metadados operacionais ou um processo excepcional de acesso a conteúdo.
- Provedor de e-mail e mecanismo de fila/retentativa.
- Necessidade de integração com fontes oficiais de movimentação processual.
- Requisitos de retenção por tipo documental e obrigação profissional.
- Hospedagem final e estratégia de recuperação.
- Se MFA será obrigatório para todos os profissionais ou inicialmente para perfis privilegiados.

## 8. Critério para avançar

Não iniciar módulos de negócio antes de:
- Aprovar o modelo lógico e a matriz de permissões.
- Criar um projeto de desenvolvimento separado.
- Implementar e testar autenticação, memberships e RLS.
- Confirmar que clientes e escritórios não conseguem acessar recursos uns dos outros.
