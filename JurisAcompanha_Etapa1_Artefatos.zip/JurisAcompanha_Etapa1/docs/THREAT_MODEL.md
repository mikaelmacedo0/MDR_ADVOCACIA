# Modelo de ameaças — JurisAcompanha

## 1. Ativos a proteger

- Dados pessoais de clientes e partes.
- Informações processuais e estratégia jurídica.
- Documentos, provas, petições e decisões.
- Credenciais, sessões e tokens.
- Relações entre usuários, escritórios e processos.
- Registros de auditoria.
- Disponibilidade da plataforma e capacidade de recuperação.

## 2. Agentes e cenários

- Usuário autenticado tentando exceder suas permissões.
- Cliente malicioso alterando IDs em URLs ou chamadas API.
- Usuário de um escritório tentando acessar outro tenant.
- Conta comprometida por senha reutilizada ou phishing.
- Atacante externo explorando falhas web.
- Upload de arquivo malicioso.
- Colaborador interno com privilégio excessivo.
- Exposição acidental por configuração de Storage, logs, backups ou segredos.
- Serviço externo comprometido ou indisponível.
- Erro de desenvolvimento que abre políticas RLS ou permite autoelevação.

## 3. Registro inicial de riscos

| ID | Risco | Impacto | Controles propostos | Validação |
|---|---|---|---|---|
| T-01 | Cliente acessa processo de outro cliente | Vazamento grave de dados jurídicos | RLS, vínculos explícitos, deny-by-default | Testes negativos com duas contas |
| T-02 | Escritório acessa dados de outro tenant | Quebra de isolamento multi-tenant | `tenant_id`, memberships confiáveis, constraints e RLS | Testes com dois tenants |
| T-03 | Documento privado exposto por URL pública | Divulgação de documentos confidenciais | Bucket privado, autorização antes de URL assinada, expiração curta | Teste de acesso anônimo e sessão indevida |
| T-04 | Usuário eleva o próprio privilégio | Acesso administrativo indevido | Papéis protegidos, operações confiáveis, RLS | Tentativa de alterar role/membership |
| T-05 | Segredo privilegiado incluído no front-end | Comprometimento do banco/serviço | Segredos apenas no servidor, revisão de bundle e repositório | Busca automatizada e inspeção |
| T-06 | Upload de arquivo malicioso | Comprometimento de usuários/serviços | Allowlist, validação real, limite, quarentena e análise antimalware quando disponível | Testes de arquivos inválidos |
| T-07 | XSS ou conteúdo não confiável | Roubo de sessão ou ações indevidas | Escape, sanitização quando necessária, CSP e validação | Testes de entradas maliciosas |
| T-08 | Função privilegiada ignora autorização | Acesso não autorizado por caminho alternativo | Validação explícita, privilégios mínimos, revisão de funções | Testes diretos da função |
| T-09 | Log expõe dados pessoais ou tokens | Vazamento secundário | Minimização, redaction, controle de acesso e retenção | Inspeção de logs de teste |
| T-10 | Backup não pode ser restaurado | Perda prolongada de dados | Backups protegidos, RPO/RTO e exercícios de restauração | Restauração documentada |
| T-11 | E-mail revela informação processual | Exposição por caixa postal ou notificação | Conteúdo mínimo, links autenticados, sem anexos por padrão | Revisão de templates |
| T-12 | Prazo jurídico incorreto é tratado como definitivo | Prejuízo ao cliente | Fonte rastreável, responsável pela conferência e aviso de validação | Testes de fluxo e revisão profissional |
| T-13 | Conta comprometida | Acesso indevido a processos | MFA para perfis privilegiados, alertas e revogação de sessão | Testes de MFA e revogação |
| T-14 | Abuso de login, API ou notificações | Indisponibilidade ou custo excessivo | Rate limits, limites de payload e retentativas controladas | Testes de carga/abuso apropriados |

## 4. Priorização

Os riscos T-01 a T-05 são bloqueadores de arquitetura: devem ser mitigados e testados antes de armazenar dados jurídicos reais.

Riscos de arquivos, funções, logs, backups e notificações devem ser tratados antes de produção. Classificação definitiva depende da implementação e do ambiente.

## 5. Resposta a incidentes

Preparar um procedimento para:
1. Detectar e registrar o evento.
2. Conter o acesso ou a integração afetada.
3. Preservar evidências necessárias sem ampliar exposição.
4. Avaliar escopo, dados envolvidos e titulares potencialmente afetados.
5. Corrigir a causa e rotacionar credenciais quando necessário.
6. Avaliar obrigações de comunicação com responsáveis e autoridades, conforme legislação aplicável.
7. Recuperar serviços e monitorar recorrência.
8. Documentar ações e lições aprendidas.

## 6. Limites e pendências

Este modelo é preliminar e não substitui avaliação profissional de segurança, privacidade ou obrigações jurídicas. Atualizá-lo após definição do provedor de hospedagem, configuração de Auth, políticas reais, integrações e fluxos de dados.
