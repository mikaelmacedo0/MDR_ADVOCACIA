# Modelo lógico de dados — JurisAcompanha

Este é um modelo conceitual inicial, não uma migração SQL pronta para produção. Tipos, constraints, índices, políticas RLS e estratégias de exclusão deverão ser definidos e revisados antes de executar migrações.

## 1. Entidades

| Entidade | Finalidade | Relações principais |
|---|---|---|
| `tenants` | Escritórios/organizações clientes do SaaS | Um tenant tem memberships, clientes e processos |
| `profiles` | Perfil associado ao usuário autenticado | Ligado ao identificador de Supabase Auth |
| `memberships` | Vínculo de usuário com escritório e estado do vínculo | Liga profiles a tenants; guarda papel ou referência a papel |
| `roles` / `permissions` | Catálogo de permissões, se RBAC granular for usado | Associados a memberships ou atribuições |
| `clients` | Cadastro do cliente no contexto de um escritório | Pertence a tenant |
| `client_user_links` | Liga uma identidade autenticada a um cadastro de cliente | Permite portal do cliente sem confiar em IDs enviados pelo navegador |
| `cases` | Processo jurídico | Pertence a tenant e tem responsável |
| `case_client_links` | Liga clientes autorizados a processos | Relação N:N, sempre dentro do mesmo tenant |
| `case_assignments` | Advogados/colaboradores autorizados no processo | Liga memberships a processos |
| `case_events` | Eventos da timeline e movimentações | Pertence a processo; registra origem e autoria |
| `case_updates` | Explicações/publicações para cliente | Pertence a processo; contém estado de publicação |
| `documents` | Metadados e política de visibilidade do documento | Pertence a tenant e processo; objeto binário no Storage |
| `document_versions` | Versões imutáveis ou versionadas de documentos | Pertence a documento |
| `calendar_events` | Audiências, reuniões e prazos | Pertence a tenant; pode se relacionar com processo |
| `tasks` | Tarefas e responsáveis | Pertence a tenant; pode se relacionar com processo |
| `notifications` | Estado e destino de notificações | Pertence a tenant e usuário destinatário |
| `notification_preferences` | Preferências do destinatário | Ligada a usuário e tenant conforme desenho final |
| `invitations` | Convites com expiração e estado | Pertence a tenant; token nunca deve ser armazenado em texto puro se for usado como segredo |
| `consent_records` | Registro de aceite quando consentimento for a base aplicável | Deve guardar finalidade/versão/data, sem presumir que todo tratamento depende de consentimento |
| `privacy_requests` | Solicitações de titulares | Pertence a tenant e tem controle de acesso restrito |
| `audit_logs` | Histórico de ações relevantes | Tenant, ator, ação, recurso, resultado e timestamp |
| `security_events` | Eventos de segurança e acesso negado | Acesso restrito; conteúdo minimizado |

## 2. Regras de integridade

1. Toda entidade de negócio pertencente a um escritório deve carregar `tenant_id` ou ter relação inequívoca e validada com uma entidade que o carregue.
2. Chaves estrangeiras compostas ou outras constraints devem impedir vínculos entre tenants diferentes quando aplicável.
3. A identidade de autenticação deve vir da sessão validada, não de um `user_id` arbitrário enviado pelo cliente.
4. Papéis e memberships não podem ser alterados livremente pelo próprio usuário.
5. Um processo pode ter vários clientes autorizados e vários profissionais atribuídos; essas relações precisam ser explícitas.
6. Visibilidade de documento e atualização deve ser definida no servidor/banco.
7. Eventos de auditoria não devem ser editáveis por usuários comuns.
8. Não apagar automaticamente registros jurídicos por exclusão de conta; definir política de retenção e anonimização com revisão jurídica.
9. Arquivos binários devem ficar em armazenamento privado, e não em campos comuns de tabelas, salvo decisão documentada.
10. Índices devem apoiar consultas por tenant, processo, status e datas sem permitir fuga de dados.

## 3. Campos comuns recomendados

Para tabelas de negócio, avaliar:
- `id` UUID como chave primária.
- `tenant_id` UUID quando aplicável.
- `created_at` e `updated_at` com timestamps consistentes.
- `created_by` / `updated_by` quando úteis para rastreabilidade.
- Estado explícito em vez de exclusão física automática.

Não adicionar campos pessoais por conveniência. Cada dado deve ter finalidade definida.

## 4. Entidade `cases` — campos iniciais

- `id`
- `tenant_id`
- `internal_title`
- `cnj_number` (opcional durante rascunho; validação de formato antes de aceitar como número válido)
- `court`
- `venue`
- `class_name`
- `subject`
- `administrative_status`
- `responsible_membership_id`
- `created_at`
- `updated_at`

O estado administrativo (ativo, suspenso, arquivado, concluso/encerrado conforme o modelo aprovado) não deve ser confundido com resultado favorável/desfavorável nem com uma situação oficial atualizada automaticamente.

## 5. Entidade `documents` — campos iniciais

- `id`
- `tenant_id`
- `case_id`
- `category`
- `storage_object_key` (chave interna, não URL pública)
- `original_filename` (tratado como dado não confiável)
- `content_type_detected`
- `size_bytes`
- `visibility` (por exemplo, `internal` ou `client_visible`)
- `scan_status`
- `uploaded_by_membership_id`
- `created_at`

As versões devem guardar hash, chave do objeto, tamanho, resultado da análise e timestamp. Links assinados não devem ser persistidos como URLs permanentes.

## 6. Índices a considerar

- Índices em `tenant_id` nas tabelas multi-tenant.
- Índices compostos para consultas frequentes, como `(tenant_id, status, updated_at)`.
- Índices nos vínculos usados por políticas RLS.
- Índice único para número CNJ por tenant se essa regra de negócio for aprovada.
- Índices em `case_id`, `client_id`, `membership_id` nas tabelas de relacionamento.
- Índices de datas para agenda e timeline.

Validar índices com consultas reais de teste e evitar índices redundantes.
