# JurisAcompanha — Etapa 1

Este pacote contém os primeiros artefatos de arquitetura e segurança do JurisAcompanha. Ainda não contém a aplicação executável nem migrações SQL de produção.

## Documentos
- `docs/ARCHITECTURE.md`: arquitetura proposta e limites de confiança.
- `docs/DATA_MODEL.md`: modelo lógico de dados inicial.
- `docs/ACCESS_CONTROL.md`: matriz de permissões e princípios de autorização.
- `docs/THREAT_MODEL.md`: modelo de ameaças e controles previstos.

## Estado
**Status:** proposta inicial para revisão.

Nenhum Supabase foi criado ou configurado. Nenhuma política foi executada ou testada. Não utilizar dados jurídicos reais nesta fase.

## Próximos passos
1. Revisar os artefatos e confirmar as decisões em aberto.
2. Criar um projeto Supabase dedicado para desenvolvimento.
3. Preparar o repositório Git e a estrutura do código.
4. Escrever migrações SQL pequenas e revisáveis.
5. Implementar autenticação e isolamento multi-tenant.
6. Testar RLS com identidades fictícias antes de desenvolver os módulos funcionais.
